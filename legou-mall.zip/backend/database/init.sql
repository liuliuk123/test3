-- ===================================
-- 乐购商城数据库初始化脚本
-- ===================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS legou_mall DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE legou_mall;

-- ===================================
-- 1. 用户表
-- ===================================
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL COMMENT '用户名',
    password VARCHAR(255) NOT NULL COMMENT '密码（加密）',
    email VARCHAR(100) COMMENT '邮箱',
    phone VARCHAR(20) COMMENT '手机号',
    avatar VARCHAR(255) DEFAULT 'https://picsum.photos/80/80' COMMENT '头像',
    role ENUM('user', 'admin') DEFAULT 'user' COMMENT '角色',
    status ENUM('active', 'inactive') DEFAULT 'active' COMMENT '状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- ===================================
-- 2. 商品分类表
-- ===================================
CREATE TABLE IF NOT EXISTS categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT '分类名称',
    description TEXT COMMENT '分类描述',
    parent_id INT DEFAULT 0 COMMENT '父分类ID，0表示顶级分类',
    sort_order INT DEFAULT 0 COMMENT '排序',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_parent_id (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品分类表';

-- ===================================
-- 3. 商品表
-- ===================================
CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id VARCHAR(50) UNIQUE NOT NULL COMMENT '商品编号',
    name VARCHAR(200) NOT NULL COMMENT '商品名称',
    description TEXT COMMENT '商品描述',
    category_id INT COMMENT '分类ID',
    price DECIMAL(10, 2) NOT NULL COMMENT '价格',
    original_price DECIMAL(10, 2) COMMENT '原价',
    stock INT DEFAULT 0 COMMENT '库存',
    sales INT DEFAULT 0 COMMENT '销量',
    image VARCHAR(500) COMMENT '主图',
    images TEXT COMMENT '商品图片（JSON数组）',
    status ENUM('active', 'inactive', 'sold_out') DEFAULT 'active' COMMENT '状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    INDEX idx_product_id (product_id),
    INDEX idx_category_id (category_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品表';

-- ===================================
-- 4. 购物车表
-- ===================================
CREATE TABLE IF NOT EXISTS cart (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT '用户ID',
    product_id INT NOT NULL COMMENT '商品ID',
    quantity INT DEFAULT 1 COMMENT '数量',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_product (user_id, product_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='购物车表';

-- ===================================
-- 5. 订单表
-- ===================================
CREATE TABLE IF NOT EXISTS orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_no VARCHAR(50) UNIQUE NOT NULL COMMENT '订单号',
    user_id INT NOT NULL COMMENT '用户ID',
    total_amount DECIMAL(10, 2) NOT NULL COMMENT '订单总金额',
    status ENUM('pending', 'paid', 'shipped', 'completed', 'cancelled') DEFAULT 'pending' COMMENT '订单状态',
    payment_method VARCHAR(50) COMMENT '支付方式',
    shipping_address TEXT COMMENT '收货地址（JSON）',
    remark TEXT COMMENT '订单备注',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_order_no (order_no),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- ===================================
-- 6. 订单详情表
-- ===================================
CREATE TABLE IF NOT EXISTS order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL COMMENT '订单ID',
    product_id INT NOT NULL COMMENT '商品ID',
    product_name VARCHAR(200) NOT NULL COMMENT '商品名称',
    product_image VARCHAR(500) COMMENT '商品图片',
    price DECIMAL(10, 2) NOT NULL COMMENT '商品单价',
    quantity INT NOT NULL COMMENT '购买数量',
    subtotal DECIMAL(10, 2) NOT NULL COMMENT '小计',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
    INDEX idx_order_id (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单详情表';

-- ===================================
-- 7. 收货地址表
-- ===================================
CREATE TABLE IF NOT EXISTS addresses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT '用户ID',
    receiver_name VARCHAR(50) NOT NULL COMMENT '收货人',
    phone VARCHAR(20) NOT NULL COMMENT '手机号',
    province VARCHAR(50) NOT NULL COMMENT '省份',
    city VARCHAR(50) NOT NULL COMMENT '城市',
    area VARCHAR(50) NOT NULL COMMENT '区县',
    detail_address VARCHAR(255) NOT NULL COMMENT '详细地址',
    zip_code VARCHAR(10) COMMENT '邮政编码',
    is_default TINYINT(1) DEFAULT 0 COMMENT '是否默认地址',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='收货地址表';

-- ===================================
-- 8. 轮播图表
-- ===================================
CREATE TABLE IF NOT EXISTS banners (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) COMMENT '标题',
    image VARCHAR(500) NOT NULL COMMENT '图片URL',
    link VARCHAR(500) COMMENT '跳转链接',
    sort_order INT DEFAULT 0 COMMENT '排序',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_sort_order (sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='轮播图表';

-- ===================================
-- 插入初始数据
-- ===================================

-- 插入管理员账号 (密码: admin123，需要在应用中加密)
INSERT INTO users (username, password, email, role, status) VALUES 
('admin', '$2a$10$xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'admin@legou.com', 'admin', 'active');

-- 插入测试用户 (密码: 123456)
INSERT INTO users (username, password, email, phone, role) VALUES 
('testuser', '$2a$10$xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'test@legou.com', '13800138000', 'user');

-- 插入商品分类
INSERT INTO categories (name, description, parent_id, sort_order) VALUES 
('电子产品', '电子数码产品', 0, 1),
('服装鞋帽', '服装服饰鞋帽', 0, 2),
('家居生活', '家居日用品', 0, 3),
('图书音像', '图书音像制品', 0, 4),
('美妆个护', '美妆护肤个护', 0, 5);

-- 插入测试商品
INSERT INTO products (product_id, name, description, category_id, price, original_price, stock, sales, image, status) VALUES 
('p001', '无线蓝牙耳机', '高品质无线蓝牙耳机，降噪设计，长续航', 1, 199.00, 299.00, 100, 520, 'https://picsum.photos/id/96/400/400', 'active'),
('p002', '纯棉休闲T恤', '100%纯棉，透气舒适，多色可选', 2, 299.00, 399.00, 200, 315, 'https://picsum.photos/id/21/400/400', 'active'),
('p003', '北欧风马克杯', '简约北欧风格，陶瓷材质，容量350ml', 3, 99.00, 129.00, 150, 280, 'https://picsum.photos/id/42/400/400', 'active'),
('p004', '保湿修护面霜', '深层补水保湿，修护肌肤屏障', 5, 499.00, 699.00, 80, 180, 'https://picsum.photos/id/24/400/400', 'active'),
('p005', '智能手环', '运动健康监测，心率血氧监测', 1, 299.00, 399.00, 120, 450, 'https://picsum.photos/id/180/400/400', 'active'),
('p006', '运动鞋', '舒适透气，防滑耐磨', 2, 399.00, 599.00, 90, 220, 'https://picsum.photos/id/21/400/400', 'active');

-- 插入轮播图
INSERT INTO banners (title, image, link, sort_order, status) VALUES 
('新品上市 - 数码家电专场', 'https://picsum.photos/id/26/1200/400', '/products?category=1', 1, 'active'),
('限时折扣 - 服饰鞋包5折起', 'https://picsum.photos/id/65/1200/400', '/products?category=2', 2, 'active'),
('会员专享 - 家居好物满减', 'https://picsum.photos/id/96/1200/400', '/products?category=3', 3, 'active');

-- ===================================
-- 结束
-- ===================================

