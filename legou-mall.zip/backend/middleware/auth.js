const jwt = require('jsonwebtoken');

// JWT密钥（添加默认值以防环境变量未配置）
const JWT_SECRET = process.env.JWT_SECRET || 'legou_mall_default_secret_key_please_change_in_production';

// JWT认证中间件
const authMiddleware = async (req, res, next) => {
    try {
        // 从请求头获取token
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                success: false,
                message: '未提供认证令牌'
            });
        }

        const token = authHeader.substring(7); // 去掉 "Bearer "

        // 验证token
        const decoded = jwt.verify(token, JWT_SECRET);
        
        // 将用户信息添加到请求对象
        req.user = decoded;
        
        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                success: false,
                message: '令牌已过期，请重新登录'
            });
        }
        
        return res.status(401).json({
            success: false,
            message: '无效的令牌'
        });
    }
};

// 管理员权限验证中间件
const adminMiddleware = (req, res, next) => {
    if (req.user && req.user.role === 'admin') {
        next();
    } else {
        res.status(403).json({
            success: false,
            message: '权限不足，仅管理员可访问'
        });
    }
};

module.exports = {
    authMiddleware,
    adminMiddleware
};

