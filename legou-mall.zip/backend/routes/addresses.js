const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');

// 所有地址路由都需要认证
router.use(authMiddleware);

// 获取用户地址列表
router.get('/', async (req, res) => {
    try {
        const userId = req.user.id;

        const [addresses] = await db.query(
            'SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, created_at DESC',
            [userId]
        );

        res.json({
            success: true,
            data: addresses
        });
    } catch (error) {
        console.error('获取地址列表错误:', error);
        res.status(500).json({
            success: false,
            message: '获取地址列表失败'
        });
    }
});

// 获取单个地址
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;

        const [addresses] = await db.query(
            'SELECT * FROM addresses WHERE id = ? AND user_id = ?',
            [id, userId]
        );

        if (addresses.length === 0) {
            return res.status(404).json({
                success: false,
                message: '地址不存在'
            });
        }

        res.json({
            success: true,
            data: addresses[0]
        });
    } catch (error) {
        console.error('获取地址错误:', error);
        res.status(500).json({
            success: false,
            message: '获取地址失败'
        });
    }
});

// 添加地址
router.post('/add', async (req, res) => {
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();

        const {
            receiver_name,
            phone,
            province,
            city,
            area,
            detail_address,
            zip_code,
            is_default = 0
        } = req.body;
        const userId = req.user.id;

        // 验证必填字段
        if (!receiver_name || !phone || !province || !city || !area || !detail_address) {
            return res.status(400).json({
                success: false,
                message: '收货人、手机号、省市区、详细地址不能为空'
            });
        }

        // 验证手机号
        const phoneReg = /^1[3-9]\d{9}$/;
        if (!phoneReg.test(phone)) {
            return res.status(400).json({
                success: false,
                message: '手机号格式不正确'
            });
        }

        // 如果设为默认地址，取消其他默认地址
        if (is_default) {
            await connection.query(
                'UPDATE addresses SET is_default = 0 WHERE user_id = ?',
                [userId]
            );
        }

        // 插入新地址
        const [result] = await connection.query(
            `INSERT INTO addresses 
             (user_id, receiver_name, phone, province, city, area, detail_address, zip_code, is_default)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [userId, receiver_name, phone, province, city, area, detail_address, zip_code || '', is_default ? 1 : 0]
        );

        await connection.commit();

        res.json({
            success: true,
            message: '地址添加成功',
            data: {
                id: result.insertId
            }
        });
    } catch (error) {
        await connection.rollback();
        console.error('添加地址错误:', error);
        res.status(500).json({
            success: false,
            message: '添加地址失败'
        });
    } finally {
        connection.release();
    }
});

// 更新地址
router.put('/update/:id', async (req, res) => {
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();

        const { id } = req.params;
        const {
            receiver_name,
            phone,
            province,
            city,
            area,
            detail_address,
            zip_code,
            is_default
        } = req.body;
        const userId = req.user.id;

        // 检查地址是否存在
        const [addresses] = await connection.query(
            'SELECT * FROM addresses WHERE id = ? AND user_id = ?',
            [id, userId]
        );

        if (addresses.length === 0) {
            await connection.rollback();
            return res.status(404).json({
                success: false,
                message: '地址不存在'
            });
        }

        // 验证手机号
        if (phone) {
            const phoneReg = /^1[3-9]\d{9}$/;
            if (!phoneReg.test(phone)) {
                await connection.rollback();
                return res.status(400).json({
                    success: false,
                    message: '手机号格式不正确'
                });
            }
        }

        // 如果设为默认地址，取消其他默认地址
        if (is_default) {
            await connection.query(
                'UPDATE addresses SET is_default = 0 WHERE user_id = ? AND id != ?',
                [userId, id]
            );
        }

        // 更新地址
        const updates = [];
        const values = [];

        if (receiver_name !== undefined) {
            updates.push('receiver_name = ?');
            values.push(receiver_name);
        }
        if (phone !== undefined) {
            updates.push('phone = ?');
            values.push(phone);
        }
        if (province !== undefined) {
            updates.push('province = ?');
            values.push(province);
        }
        if (city !== undefined) {
            updates.push('city = ?');
            values.push(city);
        }
        if (area !== undefined) {
            updates.push('area = ?');
            values.push(area);
        }
        if (detail_address !== undefined) {
            updates.push('detail_address = ?');
            values.push(detail_address);
        }
        if (zip_code !== undefined) {
            updates.push('zip_code = ?');
            values.push(zip_code);
        }
        if (is_default !== undefined) {
            updates.push('is_default = ?');
            values.push(is_default ? 1 : 0);
        }

        if (updates.length === 0) {
            await connection.rollback();
            return res.status(400).json({
                success: false,
                message: '没有要更新的字段'
            });
        }

        values.push(id, userId);

        await connection.query(
            `UPDATE addresses SET ${updates.join(', ')} WHERE id = ? AND user_id = ?`,
            values
        );

        await connection.commit();

        res.json({
            success: true,
            message: '地址更新成功'
        });
    } catch (error) {
        await connection.rollback();
        console.error('更新地址错误:', error);
        res.status(500).json({
            success: false,
            message: '更新地址失败'
        });
    } finally {
        connection.release();
    }
});

// 删除地址
router.delete('/delete/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;

        const [result] = await db.query(
            'DELETE FROM addresses WHERE id = ? AND user_id = ?',
            [id, userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: '地址不存在'
            });
        }

        res.json({
            success: true,
            message: '地址删除成功'
        });
    } catch (error) {
        console.error('删除地址错误:', error);
        res.status(500).json({
            success: false,
            message: '删除地址失败'
        });
    }
});

// 设置默认地址
router.put('/default/:id', async (req, res) => {
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();

        const { id } = req.params;
        const userId = req.user.id;

        // 检查地址是否存在
        const [addresses] = await connection.query(
            'SELECT * FROM addresses WHERE id = ? AND user_id = ?',
            [id, userId]
        );

        if (addresses.length === 0) {
            await connection.rollback();
            return res.status(404).json({
                success: false,
                message: '地址不存在'
            });
        }

        // 取消其他默认地址
        await connection.query(
            'UPDATE addresses SET is_default = 0 WHERE user_id = ?',
            [userId]
        );

        // 设置为默认地址
        await connection.query(
            'UPDATE addresses SET is_default = 1 WHERE id = ?',
            [id]
        );

        await connection.commit();

        res.json({
            success: true,
            message: '设置默认地址成功'
        });
    } catch (error) {
        await connection.rollback();
        console.error('设置默认地址错误:', error);
        res.status(500).json({
            success: false,
            message: '设置默认地址失败'
        });
    } finally {
        connection.release();
    }
});

module.exports = router;

