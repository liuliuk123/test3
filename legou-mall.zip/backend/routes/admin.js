const express = require('express');
const router = express.Router();
const db = require('../config/database');
const bcrypt = require('bcryptjs');
const { authMiddleware, adminMiddleware } = require('../middleware/auth');

// 所有管理员路由都需要认证和管理员权限
router.use(authMiddleware);
router.use(adminMiddleware);

// ==================== 商品管理 ====================

// 添加商品
router.post('/products/add', async (req, res) => {
    try {
        const {
            product_id,
            name,
            description,
            category_id,
            price,
            original_price,
            stock,
            image,
            images,
            status = 'active'
        } = req.body;

        if (!product_id || !name || !price) {
            return res.status(400).json({
                success: false,
                message: '商品编号、名称和价格不能为空'
            });
        }

        // 检查商品编号是否已存在
        const [existing] = await db.query(
            'SELECT id FROM products WHERE product_id = ?',
            [product_id]
        );

        if (existing.length > 0) {
            return res.status(400).json({
                success: false,
                message: '商品编号已存在'
            });
        }

        const [result] = await db.query(
            `INSERT INTO products 
             (product_id, name, description, category_id, price, original_price, stock, image, images, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                product_id,
                name,
                description || '',
                category_id || null,
                price,
                original_price || price,
                stock || 0,
                image || '',
                images ? JSON.stringify(images) : null,
                status
            ]
        );

        res.json({
            success: true,
            message: '商品添加成功',
            data: { id: result.insertId }
        });
    } catch (error) {
        console.error('添加商品错误:', error);
        res.status(500).json({
            success: false,
            message: '添加商品失败'
        });
    }
});

// 更新商品
router.put('/products/update/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            name,
            description,
            category_id,
            price,
            original_price,
            stock,
            image,
            images,
            status
        } = req.body;

        const updates = [];
        const values = [];

        if (name !== undefined) {
            updates.push('name = ?');
            values.push(name);
        }
        if (description !== undefined) {
            updates.push('description = ?');
            values.push(description);
        }
        if (category_id !== undefined) {
            updates.push('category_id = ?');
            values.push(category_id);
        }
        if (price !== undefined) {
            updates.push('price = ?');
            values.push(price);
        }
        if (original_price !== undefined) {
            updates.push('original_price = ?');
            values.push(original_price);
        }
        if (stock !== undefined) {
            updates.push('stock = ?');
            values.push(stock);
        }
        if (image !== undefined) {
            updates.push('image = ?');
            values.push(image);
        }
        if (images !== undefined) {
            updates.push('images = ?');
            values.push(JSON.stringify(images));
        }
        if (status !== undefined) {
            updates.push('status = ?');
            values.push(status);
        }

        if (updates.length === 0) {
            return res.status(400).json({
                success: false,
                message: '没有要更新的字段'
            });
        }

        values.push(id);

        const [result] = await db.query(
            `UPDATE products SET ${updates.join(', ')} WHERE id = ?`,
            values
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: '商品不存在'
            });
        }

        res.json({
            success: true,
            message: '商品更新成功'
        });
    } catch (error) {
        console.error('更新商品错误:', error);
        res.status(500).json({
            success: false,
            message: '更新商品失败'
        });
    }
});

// 删除商品
router.delete('/products/delete/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            'DELETE FROM products WHERE id = ?',
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: '商品不存在'
            });
        }

        res.json({
            success: true,
            message: '商品删除成功'
        });
    } catch (error) {
        console.error('删除商品错误:', error);
        res.status(500).json({
            success: false,
            message: '删除商品失败'
        });
    }
});

// ==================== 订单管理 ====================

// 获取所有订单
router.get('/orders', async (req, res) => {
    try {
        const { 
            page = 1, 
            limit = 10, 
            status = '', 
            order_no = '',
            start_date = '',
            end_date = ''
        } = req.query;
        
        const offset = (page - 1) * limit;

        let whereConditions = [];
        let queryParams = [];

        if (status) {
            whereConditions.push('o.status = ?');
            queryParams.push(status);
        }

        if (order_no) {
            whereConditions.push('o.order_no LIKE ?');
            queryParams.push(`%${order_no}%`);
        }

        if (start_date) {
            whereConditions.push('o.created_at >= ?');
            queryParams.push(start_date);
        }

        if (end_date) {
            whereConditions.push('o.created_at <= ?');
            queryParams.push(end_date);
        }

        const whereClause = whereConditions.length > 0 
            ? 'WHERE ' + whereConditions.join(' AND ')
            : '';

        // 获取总数
        const [countResult] = await db.query(
            `SELECT COUNT(*) as total FROM orders o ${whereClause}`,
            queryParams
        );
        const total = countResult[0].total;

        // 获取订单列表
        queryParams.push(parseInt(limit), offset);
        const [orders] = await db.query(
            `SELECT 
                o.*,
                u.username,
                u.phone as user_phone
             FROM orders o
             LEFT JOIN users u ON o.user_id = u.id
             ${whereClause}
             ORDER BY o.created_at DESC
             LIMIT ? OFFSET ?`,
            queryParams
        );

        // 获取订单商品
        for (const order of orders) {
            const [items] = await db.query(
                'SELECT * FROM order_items WHERE order_id = ?',
                [order.id]
            );
            order.items = items;

            // 解析收货地址
            if (order.shipping_address) {
                try {
                    order.shipping_address = JSON.parse(order.shipping_address);
                } catch (e) {
                    order.shipping_address = null;
                }
            }
        }

        res.json({
            success: true,
            data: {
                orders,
                pagination: {
                    total,
                    page: parseInt(page),
                    limit: parseInt(limit),
                    totalPages: Math.ceil(total / limit)
                }
            }
        });
    } catch (error) {
        console.error('获取订单列表错误:', error);
        res.status(500).json({
            success: false,
            message: '获取订单列表失败'
        });
    }
});

// 更新订单状态
router.put('/orders/status/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        if (!status) {
            return res.status(400).json({
                success: false,
                message: '状态不能为空'
            });
        }

        const allowedStatuses = ['pending', 'paid', 'shipped', 'completed', 'cancelled'];
        if (!allowedStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                message: '无效的订单状态'
            });
        }

        const [result] = await db.query(
            'UPDATE orders SET status = ? WHERE id = ?',
            [status, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: '订单不存在'
            });
        }

        res.json({
            success: true,
            message: '订单状态更新成功'
        });
    } catch (error) {
        console.error('更新订单状态错误:', error);
        res.status(500).json({
            success: false,
            message: '更新订单状态失败'
        });
    }
});

// ==================== 用户管理 ====================

// 获取用户列表
router.get('/users', async (req, res) => {
    try {
        const { page = 1, limit = 10, search = '', role = '' } = req.query;
        const offset = (page - 1) * limit;

        let whereConditions = [];
        let queryParams = [];

        if (search) {
            whereConditions.push('(username LIKE ? OR email LIKE ? OR phone LIKE ?)');
            const searchPattern = `%${search}%`;
            queryParams.push(searchPattern, searchPattern, searchPattern);
        }

        if (role) {
            whereConditions.push('role = ?');
            queryParams.push(role);
        }

        const whereClause = whereConditions.length > 0 
            ? 'WHERE ' + whereConditions.join(' AND ')
            : '';

        // 获取总数
        const [countResult] = await db.query(
            `SELECT COUNT(*) as total FROM users ${whereClause}`,
            queryParams
        );
        const total = countResult[0].total;

        // 获取用户列表
        queryParams.push(parseInt(limit), offset);
        const [users] = await db.query(
            `SELECT 
                id, username, email, phone, avatar, role, status, created_at, updated_at
             FROM users
             ${whereClause}
             ORDER BY created_at DESC
             LIMIT ? OFFSET ?`,
            queryParams
        );

        res.json({
            success: true,
            data: {
                users,
                pagination: {
                    total,
                    page: parseInt(page),
                    limit: parseInt(limit),
                    totalPages: Math.ceil(total / limit)
                }
            }
        });
    } catch (error) {
        console.error('获取用户列表错误:', error);
        res.status(500).json({
            success: false,
            message: '获取用户列表失败'
        });
    }
});

// 更新用户状态
router.put('/users/status/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        if (!status || !['active', 'inactive'].includes(status)) {
            return res.status(400).json({
                success: false,
                message: '无效的状态'
            });
        }

        const [result] = await db.query(
            'UPDATE users SET status = ? WHERE id = ?',
            [status, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: '用户不存在'
            });
        }

        res.json({
            success: true,
            message: '用户状态更新成功'
        });
    } catch (error) {
        console.error('更新用户状态错误:', error);
        res.status(500).json({
            success: false,
            message: '更新用户状态失败'
        });
    }
});

// ==================== 分类管理 ====================

// 添加分类
router.post('/categories/add', async (req, res) => {
    try {
        const { name, description, parent_id = 0, sort_order = 0 } = req.body;

        if (!name) {
            return res.status(400).json({
                success: false,
                message: '分类名称不能为空'
            });
        }

        const [result] = await db.query(
            'INSERT INTO categories (name, description, parent_id, sort_order) VALUES (?, ?, ?, ?)',
            [name, description || '', parent_id, sort_order]
        );

        res.json({
            success: true,
            message: '分类添加成功',
            data: { id: result.insertId }
        });
    } catch (error) {
        console.error('添加分类错误:', error);
        res.status(500).json({
            success: false,
            message: '添加分类失败'
        });
    }
});

// 更新分类
router.put('/categories/update/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { name, description, sort_order, status } = req.body;

        const updates = [];
        const values = [];

        if (name !== undefined) {
            updates.push('name = ?');
            values.push(name);
        }
        if (description !== undefined) {
            updates.push('description = ?');
            values.push(description);
        }
        if (sort_order !== undefined) {
            updates.push('sort_order = ?');
            values.push(sort_order);
        }
        if (status !== undefined) {
            updates.push('status = ?');
            values.push(status);
        }

        if (updates.length === 0) {
            return res.status(400).json({
                success: false,
                message: '没有要更新的字段'
            });
        }

        values.push(id);

        const [result] = await db.query(
            `UPDATE categories SET ${updates.join(', ')} WHERE id = ?`,
            values
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: '分类不存在'
            });
        }

        res.json({
            success: true,
            message: '分类更新成功'
        });
    } catch (error) {
        console.error('更新分类错误:', error);
        res.status(500).json({
            success: false,
            message: '更新分类失败'
        });
    }
});

// 删除分类
router.delete('/categories/delete/:id', async (req, res) => {
    try {
        const { id } = req.params;

        // 检查是否有子分类
        const [children] = await db.query(
            'SELECT id FROM categories WHERE parent_id = ?',
            [id]
        );

        if (children.length > 0) {
            return res.status(400).json({
                success: false,
                message: '该分类下有子分类，无法删除'
            });
        }

        // 检查是否有商品
        const [products] = await db.query(
            'SELECT id FROM products WHERE category_id = ?',
            [id]
        );

        if (products.length > 0) {
            return res.status(400).json({
                success: false,
                message: '该分类下有商品，无法删除'
            });
        }

        const [result] = await db.query(
            'DELETE FROM categories WHERE id = ?',
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: '分类不存在'
            });
        }

        res.json({
            success: true,
            message: '分类删除成功'
        });
    } catch (error) {
        console.error('删除分类错误:', error);
        res.status(500).json({
            success: false,
            message: '删除分类失败'
        });
    }
});

// ==================== 轮播图管理 ====================

// 获取所有轮播图
router.get('/banners', async (req, res) => {
    try {
        const [banners] = await db.query(
            'SELECT * FROM banners ORDER BY sort_order ASC, created_at DESC'
        );

        res.json({
            success: true,
            data: banners
        });
    } catch (error) {
        console.error('获取轮播图错误:', error);
        res.status(500).json({
            success: false,
            message: '获取轮播图失败'
        });
    }
});

// 添加轮播图
router.post('/banners/add', async (req, res) => {
    try {
        const { title, image, link, sort_order = 0 } = req.body;

        if (!image) {
            return res.status(400).json({
                success: false,
                message: '图片不能为空'
            });
        }

        const [result] = await db.query(
            'INSERT INTO banners (title, image, link, sort_order) VALUES (?, ?, ?, ?)',
            [title || '', image, link || '', sort_order]
        );

        res.json({
            success: true,
            message: '轮播图添加成功',
            data: { id: result.insertId }
        });
    } catch (error) {
        console.error('添加轮播图错误:', error);
        res.status(500).json({
            success: false,
            message: '添加轮播图失败'
        });
    }
});

// 更新轮播图
router.put('/banners/update/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { title, image, link, sort_order, status } = req.body;

        const updates = [];
        const values = [];

        if (title !== undefined) {
            updates.push('title = ?');
            values.push(title);
        }
        if (image !== undefined) {
            updates.push('image = ?');
            values.push(image);
        }
        if (link !== undefined) {
            updates.push('link = ?');
            values.push(link);
        }
        if (sort_order !== undefined) {
            updates.push('sort_order = ?');
            values.push(sort_order);
        }
        if (status !== undefined) {
            updates.push('status = ?');
            values.push(status);
        }

        if (updates.length === 0) {
            return res.status(400).json({
                success: false,
                message: '没有要更新的字段'
            });
        }

        values.push(id);

        const [result] = await db.query(
            `UPDATE banners SET ${updates.join(', ')} WHERE id = ?`,
            values
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: '轮播图不存在'
            });
        }

        res.json({
            success: true,
            message: '轮播图更新成功'
        });
    } catch (error) {
        console.error('更新轮播图错误:', error);
        res.status(500).json({
            success: false,
            message: '更新轮播图失败'
        });
    }
});

// 删除轮播图
router.delete('/banners/delete/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const [result] = await db.query(
            'DELETE FROM banners WHERE id = ?',
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: '轮播图不存在'
            });
        }

        res.json({
            success: true,
            message: '轮播图删除成功'
        });
    } catch (error) {
        console.error('删除轮播图错误:', error);
        res.status(500).json({
            success: false,
            message: '删除轮播图失败'
        });
    }
});

// ==================== 统计数据 ====================

// 获取仪表盘统计数据
router.get('/dashboard/stats', async (req, res) => {
    try {
        // 用户总数
        const [userCount] = await db.query('SELECT COUNT(*) as count FROM users WHERE role = "user"');
        
        // 商品总数
        const [productCount] = await db.query('SELECT COUNT(*) as count FROM products');
        
        // 订单总数
        const [orderCount] = await db.query('SELECT COUNT(*) as count FROM orders');
        
        // 今日订单数
        const [todayOrderCount] = await db.query(
            'SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE()'
        );
        
        // 总销售额
        const [totalSales] = await db.query(
            'SELECT SUM(total_amount) as total FROM orders WHERE status != "cancelled"'
        );
        
        // 待处理订单数
        const [pendingOrderCount] = await db.query(
            'SELECT COUNT(*) as count FROM orders WHERE status = "pending"'
        );

        res.json({
            success: true,
            data: {
                userCount: userCount[0].count,
                productCount: productCount[0].count,
                orderCount: orderCount[0].count,
                todayOrderCount: todayOrderCount[0].count,
                totalSales: parseFloat(totalSales[0].total || 0).toFixed(2),
                pendingOrderCount: pendingOrderCount[0].count
            }
        });
    } catch (error) {
        console.error('获取统计数据错误:', error);
        res.status(500).json({
            success: false,
            message: '获取统计数据失败'
        });
    }
});

module.exports = router;

