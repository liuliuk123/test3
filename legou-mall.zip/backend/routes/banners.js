const express = require('express');
const router = express.Router();
const db = require('../config/database');

// 获取轮播图列表
router.get('/', async (req, res) => {
    try {
        const [banners] = await db.query(
            'SELECT * FROM banners WHERE status = "active" ORDER BY sort_order ASC, created_at DESC'
        );

        res.json({
            success: true,
            data: banners
        });
    } catch (error) {
        console.error('获取轮播图错误:', error);
        res.status(500).json({
            success: false,
            message: '获取轮播图失败'
        });
    }
});

module.exports = router;

