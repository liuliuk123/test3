const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');

// 所有购物车路由都需要认证
router.use(authMiddleware);

// 获取购物车列表
router.get('/', async (req, res) => {
    try {
        const userId = req.user.id;

        const [cartItems] = await db.query(
            `SELECT 
                c.id,
                c.quantity,
                p.id as product_id,
                p.product_id as product_code,
                p.name,
                p.price,
                p.image,
                p.stock,
                p.status
             FROM cart c
             INNER JOIN products p ON c.product_id = p.id
             WHERE c.user_id = ?
             ORDER BY c.created_at DESC`,
            [userId]
        );

        // 计算总价
        const totalPrice = cartItems.reduce((sum, item) => {
            return sum + (item.price * item.quantity);
        }, 0);

        res.json({
            success: true,
            data: {
                items: cartItems,
                totalPrice: parseFloat(totalPrice.toFixed(2)),
                totalItems: cartItems.reduce((sum, item) => sum + item.quantity, 0)
            }
        });
    } catch (error) {
        console.error('获取购物车错误:', error);
        res.status(500).json({
            success: false,
            message: '获取购物车失败'
        });
    }
});

// 添加商品到购物车
router.post('/add', async (req, res) => {
    try {
        const { product_id, quantity = 1 } = req.body;
        const userId = req.user.id;

        if (!product_id) {
            return res.status(400).json({
                success: false,
                message: '商品ID不能为空'
            });
        }

        // 检查商品是否存在且有库存
        const [products] = await db.query(
            'SELECT id, stock, status FROM products WHERE id = ?',
            [product_id]
        );

        if (products.length === 0) {
            return res.status(404).json({
                success: false,
                message: '商品不存在'
            });
        }

        const product = products[0];

        if (product.status !== 'active') {
            return res.status(400).json({
                success: false,
                message: '商品已下架'
            });
        }

        if (product.stock < quantity) {
            return res.status(400).json({
                success: false,
                message: '库存不足'
            });
        }

        // 检查购物车中是否已有该商品
        const [existingCart] = await db.query(
            'SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?',
            [userId, product_id]
        );

        if (existingCart.length > 0) {
            // 更新数量
            const newQuantity = existingCart[0].quantity + quantity;
            
            if (product.stock < newQuantity) {
                return res.status(400).json({
                    success: false,
                    message: '库存不足'
                });
            }

            await db.query(
                'UPDATE cart SET quantity = ? WHERE id = ?',
                [newQuantity, existingCart[0].id]
            );
        } else {
            // 添加新商品
            await db.query(
                'INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)',
                [userId, product_id, quantity]
            );
        }

        res.json({
            success: true,
            message: '添加成功'
        });
    } catch (error) {
        console.error('添加购物车错误:', error);
        res.status(500).json({
            success: false,
            message: '添加购物车失败'
        });
    }
});

// 更新购物车商品数量
router.put('/update/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { quantity } = req.body;
        const userId = req.user.id;

        if (!quantity || quantity < 1) {
            return res.status(400).json({
                success: false,
                message: '数量必须大于0'
            });
        }

        // 检查购物车项是否存在且属于当前用户
        const [cartItems] = await db.query(
            `SELECT c.id, c.product_id, p.stock 
             FROM cart c
             INNER JOIN products p ON c.product_id = p.id
             WHERE c.id = ? AND c.user_id = ?`,
            [id, userId]
        );

        if (cartItems.length === 0) {
            return res.status(404).json({
                success: false,
                message: '购物车项不存在'
            });
        }

        const cartItem = cartItems[0];

        if (cartItem.stock < quantity) {
            return res.status(400).json({
                success: false,
                message: '库存不足'
            });
        }

        await db.query(
            'UPDATE cart SET quantity = ? WHERE id = ?',
            [quantity, id]
        );

        res.json({
            success: true,
            message: '更新成功'
        });
    } catch (error) {
        console.error('更新购物车错误:', error);
        res.status(500).json({
            success: false,
            message: '更新购物车失败'
        });
    }
});

// 删除购物车商品
router.delete('/remove/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;

        const [result] = await db.query(
            'DELETE FROM cart WHERE id = ? AND user_id = ?',
            [id, userId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: '购物车项不存在'
            });
        }

        res.json({
            success: true,
            message: '删除成功'
        });
    } catch (error) {
        console.error('删除购物车错误:', error);
        res.status(500).json({
            success: false,
            message: '删除购物车失败'
        });
    }
});

// 清空购物车
router.delete('/clear', async (req, res) => {
    try {
        const userId = req.user.id;

        await db.query('DELETE FROM cart WHERE user_id = ?', [userId]);

        res.json({
            success: true,
            message: '购物车已清空'
        });
    } catch (error) {
        console.error('清空购物车错误:', error);
        res.status(500).json({
            success: false,
            message: '清空购物车失败'
        });
    }
});

module.exports = router;

