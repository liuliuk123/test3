const express = require('express');
const router = express.Router();
const db = require('../config/database');

// 获取所有分类
router.get('/', async (req, res) => {
    try {
        const [categories] = await db.query(
            'SELECT * FROM categories WHERE status = "active" ORDER BY sort_order ASC, id ASC'
        );

        // 构建分类树
        const categoryTree = [];
        const categoryMap = new Map();

        // 先将所有分类放入Map
        categories.forEach(cat => {
            categoryMap.set(cat.id, { ...cat, children: [] });
        });

        // 构建树形结构
        categories.forEach(cat => {
            const category = categoryMap.get(cat.id);
            if (cat.parent_id === 0) {
                categoryTree.push(category);
            } else {
                const parent = categoryMap.get(cat.parent_id);
                if (parent) {
                    parent.children.push(category);
                }
            }
        });

        res.json({
            success: true,
            data: categoryTree
        });
    } catch (error) {
        console.error('获取分类错误:', error);
        res.status(500).json({
            success: false,
            message: '获取分类失败'
        });
    }
});

// 获取单个分类
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const [categories] = await db.query(
            'SELECT * FROM categories WHERE id = ?',
            [id]
        );

        if (categories.length === 0) {
            return res.status(404).json({
                success: false,
                message: '分类不存在'
            });
        }

        res.json({
            success: true,
            data: categories[0]
        });
    } catch (error) {
        console.error('获取分类错误:', error);
        res.status(500).json({
            success: false,
            message: '获取分类失败'
        });
    }
});

module.exports = router;

