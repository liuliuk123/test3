const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authMiddleware } = require('../middleware/auth');

// 所有订单路由都需要认证
router.use(authMiddleware);

// 生成订单号
function generateOrderNo() {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `ORD${timestamp}${random}`;
}

// 创建订单
router.post('/create', async (req, res) => {
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();

        const { items, address_id, payment_method = 'alipay', remark = '' } = req.body;
        const userId = req.user.id;

        if (!items || items.length === 0) {
            return res.status(400).json({
                success: false,
                message: '请选择要购买的商品'
            });
        }

        // 获取收货地址
        let shippingAddress = null;
        if (address_id) {
            const [addresses] = await connection.query(
                'SELECT * FROM addresses WHERE id = ? AND user_id = ?',
                [address_id, userId]
            );
            if (addresses.length > 0) {
                shippingAddress = addresses[0];
            }
        }

        // 验证商品并计算总价
        let totalAmount = 0;
        const orderItems = [];

        for (const item of items) {
            // 从数据库获取商品信息（验证商品存在且价格正确）
            const [products] = await connection.query(
                'SELECT id, product_id, name, price, stock, image FROM products WHERE product_id = ?',
                [item.id]
            );

            if (products.length === 0) {
                await connection.rollback();
                return res.status(404).json({
                    success: false,
                    message: `商品 ${item.name} 不存在`
                });
            }

            const product = products[0];

            // 检查库存
            if (product.stock < item.quantity) {
                await connection.rollback();
                return res.status(400).json({
                    success: false,
                    message: `商品 ${product.name} 库存不足`
                });
            }

            // 使用数据库中的价格（防止前端篡改）
            const subtotal = product.price * item.quantity;
            totalAmount += subtotal;

            orderItems.push({
                product_id: product.id,
                product_name: product.name,
                product_image: product.image,
                price: product.price,
                quantity: item.quantity,
                subtotal: subtotal
            });
        }

        // 创建订单（默认已支付状态）
        const orderNo = generateOrderNo();
        const [orderResult] = await connection.query(
            `INSERT INTO orders 
             (order_no, user_id, total_amount, status, payment_method, payment_time, shipping_address, remark)
             VALUES (?, ?, ?, 'paid', ?, NOW(), ?, ?)`,
            [
                orderNo,
                userId,
                totalAmount,
                payment_method,
                shippingAddress ? JSON.stringify(shippingAddress) : null,
                remark
            ]
        );

        const orderId = orderResult.insertId;

        // 创建订单详情
        for (const item of orderItems) {
            await connection.query(
                `INSERT INTO order_items 
                 (order_id, product_id, product_name, product_image, price, quantity, subtotal)
                 VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [
                    orderId,
                    item.product_id,
                    item.product_name,
                    item.product_image,
                    item.price,
                    item.quantity,
                    item.subtotal
                ]
            );

            // 减少商品库存，增加销量
            await connection.query(
                'UPDATE products SET stock = stock - ?, sales = sales + ? WHERE id = ?',
                [item.quantity, item.quantity, item.product_id]
            );
        }

        await connection.commit();

        res.json({
            success: true,
            message: '订单创建成功，支付完成',
            data: {
                order_id: orderId,
                order_no: orderNo,
                total_amount: totalAmount
            }
        });
    } catch (error) {
        await connection.rollback();
        console.error('创建订单错误:', error);
        res.status(500).json({
            success: false,
            message: '创建订单失败'
        });
    } finally {
        connection.release();
    }
});

// 获取订单列表
router.get('/', async (req, res) => {
    try {
        const { page = 1, limit = 10, status = '' } = req.query;
        const userId = req.user.id;
        const offset = (page - 1) * limit;

        let whereClause = 'WHERE user_id = ?';
        const queryParams = [userId];

        if (status) {
            whereClause += ' AND status = ?';
            queryParams.push(status);
        }

        // 获取总数
        const [countResult] = await db.query(
            `SELECT COUNT(*) as total FROM orders ${whereClause}`,
            queryParams
        );
        const total = countResult[0].total;

        // 获取订单列表
        queryParams.push(parseInt(limit), offset);
        const [orders] = await db.query(
            `SELECT * FROM orders ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
            queryParams
        );

        // 获取每个订单的商品详情
        for (const order of orders) {
            const [items] = await db.query(
                'SELECT * FROM order_items WHERE order_id = ?',
                [order.id]
            );
            order.items = items;
            
            // 解析收货地址
            if (order.shipping_address) {
                try {
                    order.shipping_address = JSON.parse(order.shipping_address);
                } catch (e) {
                    order.shipping_address = null;
                }
            }
        }

        res.json({
            success: true,
            data: {
                orders,
                pagination: {
                    total,
                    page: parseInt(page),
                    limit: parseInt(limit),
                    totalPages: Math.ceil(total / limit)
                }
            }
        });
    } catch (error) {
        console.error('获取订单列表错误:', error);
        res.status(500).json({
            success: false,
            message: '获取订单列表失败'
        });
    }
});

// 获取订单详情
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;

        const [orders] = await db.query(
            'SELECT * FROM orders WHERE (id = ? OR order_no = ?) AND user_id = ?',
            [id, id, userId]
        );

        if (orders.length === 0) {
            return res.status(404).json({
                success: false,
                message: '订单不存在'
            });
        }

        const order = orders[0];

        // 获取订单商品
        const [items] = await db.query(
            'SELECT * FROM order_items WHERE order_id = ?',
            [order.id]
        );
        order.items = items;

        // 解析收货地址
        if (order.shipping_address) {
            try {
                order.shipping_address = JSON.parse(order.shipping_address);
            } catch (e) {
                order.shipping_address = null;
            }
        }

        res.json({
            success: true,
            data: order
        });
    } catch (error) {
        console.error('获取订单详情错误:', error);
        res.status(500).json({
            success: false,
            message: '获取订单详情失败'
        });
    }
});

// 取消订单
router.put('/:id/cancel', async (req, res) => {
    const connection = await db.getConnection();
    
    try {
        await connection.beginTransaction();

        const { id } = req.params;
        const userId = req.user.id;

        // 查询订单
        const [orders] = await connection.query(
            'SELECT * FROM orders WHERE id = ? AND user_id = ?',
            [id, userId]
        );

        if (orders.length === 0) {
            await connection.rollback();
            return res.status(404).json({
                success: false,
                message: '订单不存在'
            });
        }

        const order = orders[0];

        // 只有待支付状态的订单可以取消
        if (order.status !== 'pending') {
            await connection.rollback();
            return res.status(400).json({
                success: false,
                message: '该订单无法取消'
            });
        }

        // 更新订单状态
        await connection.query(
            'UPDATE orders SET status = "cancelled" WHERE id = ?',
            [id]
        );

        // 恢复商品库存和销量
        const [items] = await connection.query(
            'SELECT product_id, quantity FROM order_items WHERE order_id = ?',
            [id]
        );

        for (const item of items) {
            await connection.query(
                'UPDATE products SET stock = stock + ?, sales = sales - ? WHERE id = ?',
                [item.quantity, item.quantity, item.product_id]
            );
        }

        await connection.commit();

        res.json({
            success: true,
            message: '订单已取消'
        });
    } catch (error) {
        await connection.rollback();
        console.error('取消订单错误:', error);
        res.status(500).json({
            success: false,
            message: '取消订单失败'
        });
    } finally {
        connection.release();
    }
});

// 确认收货
router.put('/:id/confirm', async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;

        // 查询订单
        const [orders] = await db.query(
            'SELECT * FROM orders WHERE id = ? AND user_id = ?',
            [id, userId]
        );

        if (orders.length === 0) {
            return res.status(404).json({
                success: false,
                message: '订单不存在'
            });
        }

        const order = orders[0];

        // 只有已发货状态的订单可以确认收货
        if (order.status !== 'shipped') {
            return res.status(400).json({
                success: false,
                message: '该订单无法确认收货'
            });
        }

        // 更新订单状态
        await db.query(
            'UPDATE orders SET status = "completed" WHERE id = ?',
            [id]
        );

        res.json({
            success: true,
            message: '确认收货成功'
        });
    } catch (error) {
        console.error('确认收货错误:', error);
        res.status(500).json({
            success: false,
            message: '确认收货失败'
        });
    }
});

module.exports = router;

