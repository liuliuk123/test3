const express = require('express');
const router = express.Router();
const db = require('../config/database');

// 获取所有商品（支持分页、搜索、分类筛选）
router.get('/', async (req, res) => {
    try {
        const { 
            page = 1, 
            limit = 10, 
            search = '', 
            category_id = '', 
            status = 'active',
            sort = 'created_at',
            order = 'DESC'
        } = req.query;

        const offset = (page - 1) * limit;
        
        let whereConditions = [];
        let queryParams = [];

        // 搜索条件
        if (search) {
            whereConditions.push('(p.name LIKE ? OR p.product_id LIKE ? OR p.description LIKE ?)');
            const searchPattern = `%${search}%`;
            queryParams.push(searchPattern, searchPattern, searchPattern);
        }

        // 分类筛选
        if (category_id) {
            whereConditions.push('p.category_id = ?');
            queryParams.push(category_id);
        }

        // 状态筛选
        if (status) {
            whereConditions.push('p.status = ?');
            queryParams.push(status);
        }

        const whereClause = whereConditions.length > 0 
            ? 'WHERE ' + whereConditions.join(' AND ')
            : '';

        // 获取总数
        const [countResult] = await db.query(
            `SELECT COUNT(*) as total 
             FROM products p 
             ${whereClause}`,
            queryParams
        );
        const total = countResult[0].total;

        // 获取商品列表
        const allowedSortFields = ['created_at', 'price', 'sales', 'stock', 'name'];
        const sortField = allowedSortFields.includes(sort) ? sort : 'created_at';
        const sortOrder = order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

        queryParams.push(parseInt(limit), offset);

        const [products] = await db.query(
            `SELECT 
                p.*,
                c.name as category_name
             FROM products p
             LEFT JOIN categories c ON p.category_id = c.id
             ${whereClause}
             ORDER BY p.${sortField} ${sortOrder}
             LIMIT ? OFFSET ?`,
            queryParams
        );

        res.json({
            success: true,
            data: {
                products,
                pagination: {
                    total,
                    page: parseInt(page),
                    limit: parseInt(limit),
                    totalPages: Math.ceil(total / limit)
                }
            }
        });
    } catch (error) {
        console.error('获取商品列表错误:', error);
        res.status(500).json({
            success: false,
            message: '获取商品列表失败'
        });
    }
});

// 获取单个商品详情
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const [products] = await db.query(
            `SELECT 
                p.*,
                c.name as category_name
             FROM products p
             LEFT JOIN categories c ON p.category_id = c.id
             WHERE p.id = ? OR p.product_id = ?`,
            [id, id]
        );

        if (products.length === 0) {
            return res.status(404).json({
                success: false,
                message: '商品不存在'
            });
        }

        res.json({
            success: true,
            data: products[0]
        });
    } catch (error) {
        console.error('获取商品详情错误:', error);
        res.status(500).json({
            success: false,
            message: '获取商品详情失败'
        });
    }
});

// 获取热门商品
router.get('/hot/list', async (req, res) => {
    try {
        const { limit = 10 } = req.query;

        const [products] = await db.query(
            `SELECT 
                p.*,
                c.name as category_name
             FROM products p
             LEFT JOIN categories c ON p.category_id = c.id
             WHERE p.status = 'active'
             ORDER BY p.sales DESC
             LIMIT ?`,
            [parseInt(limit)]
        );

        res.json({
            success: true,
            data: products
        });
    } catch (error) {
        console.error('获取热门商品错误:', error);
        res.status(500).json({
            success: false,
            message: '获取热门商品失败'
        });
    }
});

// 获取推荐商品
router.get('/recommend/list', async (req, res) => {
    try {
        const { limit = 10 } = req.query;

        const [products] = await db.query(
            `SELECT 
                p.*,
                c.name as category_name
             FROM products p
             LEFT JOIN categories c ON p.category_id = c.id
             WHERE p.status = 'active'
             ORDER BY RAND()
             LIMIT ?`,
            [parseInt(limit)]
        );

        res.json({
            success: true,
            data: products
        });
    } catch (error) {
        console.error('获取推荐商品错误:', error);
        res.status(500).json({
            success: false,
            message: '获取推荐商品失败'
        });
    }
});

module.exports = router;

