const bcrypt = require('bcryptjs');

// 生成加密密码
async function generatePassword(password) {
    const hashed = await bcrypt.hash(password, 10);
    console.log(`密码: ${password}`);
    console.log(`加密后: ${hashed}`);
    console.log('\nSQL语句:');
    console.log(`INSERT INTO users (username, password, email, role, status) VALUES ('admin', '${hashed}', 'admin@legou.com', 'admin', 'active');`);
}

// 生成默认密码
generatePassword('123456');

